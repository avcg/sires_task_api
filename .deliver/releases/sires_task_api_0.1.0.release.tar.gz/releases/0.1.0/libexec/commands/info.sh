#!/usr/bin/env bash

set -e

release_remote_ctl info "$@"
